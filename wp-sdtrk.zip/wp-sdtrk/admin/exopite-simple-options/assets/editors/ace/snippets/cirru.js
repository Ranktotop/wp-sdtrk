ace.define("ace/snippets/cirru",["require","exports","module"],function(e,t,n){"use strict";t.snippetText="",t.scope="cirru"});
                (function() {
                    ace.require(["ace/snippets/cirru"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            